Spiridon Sergiu-Mihai

	Proiectul consta intr-o aplicatie android de stiri despre diverse facultati de care
	un user ar putea fi interesat. Un client are acces la o lista de facultati si se poate
	abona la ele, insemnand ca va primi in feed-ul sau postari facute de acea facultate.

	Aplicatia are un repository in care am hardcodat doua universitati si doi useri(dintre
	care unul este admin), care tine rol de baza de date.

	Atunci cand se face o postare de catre o facultate, aceasta o sa apara in feed-ul userilor
	care sunt abonati la stiri de la acea faclutate.

	Pentru a face o postare trebuie sa fii logat ca admin(default esti admin).

	Am folosit 3 design patternuri in implementarea aplicatiei.

	1. Observer
	    Clientii sunt observers, iar facultatile observable, astfel atunci cand un client
	    se aboneaza la o facultate el este pus in lista de observeri ai facultatii si este
	    anuntat atunci cand se face o postare noua odata cu toti ceilalti clienti abonati la ea.

    2. Builder
        Am folosit acest design pattern pentru postari, deoarece ele pot avea complexitati diferite.
        De exemplu, o postare poate sau nu sa contina o poza, caz in care aceasta ar fi adaugata peste
        obiectul de baza, sau poate sa contina o bara de rating. In clasa BasicPost apar mai multe fielduri,
        dar momentan, pentru simplitate exita doar optiunea de a adauga text, o imagine sau o bara de rating
        la o postare.

    3. Singleton
        Acest design pattern este folosit la clasa Repository, deoarece doresc sa fie folosita acceasi
        instanta a clasei in tot proiectul.
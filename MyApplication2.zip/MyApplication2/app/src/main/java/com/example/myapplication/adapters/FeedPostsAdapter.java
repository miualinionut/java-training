package com.example.myapplication.adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.myapplication.R;
import com.example.myapplication.posts.BasicPost;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class FeedPostsAdapter extends ArrayAdapter<BasicPost> {
    ArrayList<BasicPost> basicPostArrayList;
    private int layoutResourceId;
    private Context context;


    public FeedPostsAdapter(@NonNull Context context, int resource, ArrayList<BasicPost> basicPostArrayList) {
        super(context, resource, basicPostArrayList);
        this.context = context;
        this.layoutResourceId = resource;
        this.basicPostArrayList = basicPostArrayList;
    }

    @SuppressLint("ViewHolder")
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        PostHolder holder = null;

        LayoutInflater inflater = ((Activity) context).getLayoutInflater();
        row = inflater.inflate(layoutResourceId, parent, false);

        holder = new FeedPostsAdapter.PostHolder();

        holder.post = basicPostArrayList.get(position);

        holder.author = (TextView) row.findViewById(R.id.text_author);

        holder.text = (TextView) row.findViewById(R.id.text_feed);

        holder.image = (ImageView) row.findViewById(R.id.imageView);

        holder.ratingBar = (RatingBar) row.findViewById(R.id.ratingBar);

        row.setTag(holder);

        try {
            setupItem(holder);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return row;
    }

    private void setupItem(PostHolder postHolder) throws IOException {

        BasicPost post = postHolder.post;

        postHolder.author.setText(post.getPostDescription());

        if (post.getText() != null) {
            postHolder.text.setText(post.getText());
        } else {
            postHolder.text.setVisibility(View.INVISIBLE);
        }

//        if (post.getLinkToAPicture() == null) {
//            InputStream is = (InputStream) new URL(post.getLinkToAPicture()).getContent();
//            Drawable d = Drawable.createFromStream(is, "src name");
//            postHolder.image.setImageDrawable(d);
//        } else {
//            postHolder.image.setVisibility(View.INVISIBLE);
//        }

        if (post.getLinkToAPicture() == null) {
            postHolder.image.setVisibility(View.GONE);
        }

        if (post.getRatingBar()) {
            postHolder.ratingBar.setVisibility(View.VISIBLE);
        } else {
            postHolder.ratingBar.setVisibility(View.INVISIBLE);
        }

    }

    public static class PostHolder {
        BasicPost post;
        TextView author;
        TextView text;
        ImageView image;
        RatingBar ratingBar;

    }
}

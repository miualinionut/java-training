package com.example.myapplication.activities;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.users.Client;
import com.example.myapplication.users.Repository;
import com.google.android.material.textfield.TextInputEditText;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Optional;

public class LoginPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.login_page);

        TextView currentUsername = (TextView) findViewById(R.id.textView2);

        currentUsername.setText(Repository.getInstance().getClientArrayList().get(
                Repository.getInstance().getIdOfTheClientThatIsLoggedIn()).getUserName());
    }

    @Override
    protected void onStart() {
        super.onStart();

        setContentView(R.layout.login_page);

        TextView currentUsername = (TextView) findViewById(R.id.textView2);

        currentUsername.setText(Repository.getInstance().getClientArrayList().get(
                Repository.getInstance().getIdOfTheClientThatIsLoggedIn()).getUserName());
    }

    public void goToPreviousPage(View view) {
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(i);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void login(View view) {
        TextInputEditText wantedUsername = (TextInputEditText) findViewById(R.id.inputed_username);

        if (wantedUsername.getText() == null) {
            return;
        }

        String nameOfUser = wantedUsername.getText().toString();
        ArrayList<Client> copyOfClientsArray = Repository.getInstance().getClientArrayList();

        for (int i = 0; i < copyOfClientsArray.size(); i++) {
            if (copyOfClientsArray.get(i).getUserName().equals(nameOfUser)) {
                Repository.getInstance().setIdOfTheClientThatIsLoggedIn(i);
                break;
            }
        }

    }

}

package com.example.myapplication.users;

import com.example.myapplication.posts.BasicPost;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class Client implements Observer {

    private String userName;
    private ArrayList<BasicPost> postsInFeed;
    private ArrayList<Faculty> listOfFacultiesWatched;

    public Client(String userName) {
        this.userName = userName;
        this.postsInFeed = new ArrayList<>();
        this.listOfFacultiesWatched = new ArrayList<>();
    }

    @Override
    public void update(Observable o, Object arg) {
        BasicPost newPost = (BasicPost) arg;

        postsInFeed.add(newPost);

        System.out.println("is updated with " + newPost.getPostDescription());
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public ArrayList<BasicPost> getPostsInFeed() {
        return postsInFeed;
    }

    public void setPostsInFeed(ArrayList<BasicPost> postsInFeed) {
        this.postsInFeed = postsInFeed;
    }

    public void addNewFacultyToWatchList(Faculty faculty) {
        if (!listOfFacultiesWatched.contains(faculty)) {
            listOfFacultiesWatched.add(faculty);
        }
    }

    public void removeFacultyToWatchList(Faculty faculty) {
        if (listOfFacultiesWatched.contains(faculty)) {
            listOfFacultiesWatched.remove(faculty);
        }
    }
}

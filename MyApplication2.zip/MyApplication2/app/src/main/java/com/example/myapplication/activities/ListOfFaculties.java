package com.example.myapplication.activities;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.adapters.FacultyListAdapterArray;
import com.example.myapplication.users.Faculty;
import com.example.myapplication.users.Repository;

import java.util.ArrayList;

public class ListOfFaculties extends ListActivity {

    ArrayList<String> listItems=new ArrayList<String>();
    ArrayAdapter<String> adapter;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_of_faculties);

        adapter = new FacultyListAdapterArray(this, R.layout.item_from_faculty_list, listItems);

        setListAdapter(adapter);

        Repository.getInstance().getFacultyArrayList().forEach(faculty -> {
            listItems.add(faculty.getName());
            adapter.notifyDataSetChanged();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        setContentView(R.layout.list_of_faculties);
    }

    public void goToPreviousPage(View view) {
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(i);
    }

//    @Override
//    protected void onListItemClick(ListView l, View v, int position, long id) {
//        super.onListItemClick(l, v, position, id);
//
//        String nameOfFacultyToObserve = (String) getListView().getItemAtPosition(position);
//        Faculty facultyToObserve = null;
//
//        for (Faculty i : Repository.getInstance().getFacultyArrayList()) {
//            if (i.getName().equals(nameOfFacultyToObserve)) {
//                facultyToObserve = i;
//            }
//        }
//
//        if (facultyToObserve != null) {
//            facultyToObserve.addToFollowers(Repository.getInstance().getClientArrayList().get(0));
//
//            System.out.println(facultyToObserve.countObservers());
//        }
//    }

    public void subscribeToFaculty(View view) {
        String nameOfFacultyToObserve = (String) view.getTag();

        Faculty facultyToObserve = null;

        for (Faculty i : Repository.getInstance().getFacultyArrayList()) {
            if (i.getName().equals(nameOfFacultyToObserve)) {
                facultyToObserve = i;
            }
        }

        if (facultyToObserve != null) {
            facultyToObserve.addToFollowers(Repository.getInstance().getClientArrayList().get(
                    Repository.getInstance().getIdOfTheClientThatIsLoggedIn()
            ));

            System.out.println(facultyToObserve.countObservers());
        }
    }

    public void unsubscribeFromFaculty(View view) {
        String nameOfFacultyToObserve = (String) view.getTag();

        Faculty facultyToUnsubscribeFrom = null;

        for (Faculty i : Repository.getInstance().getFacultyArrayList()) {
            if (i.getName().equals(nameOfFacultyToObserve)) {
                facultyToUnsubscribeFrom = i;
            }
        }

        if (facultyToUnsubscribeFrom != null) {
            facultyToUnsubscribeFrom.removeFollowers(Repository.getInstance().getClientArrayList().get(
                    Repository.getInstance().getIdOfTheClientThatIsLoggedIn()
            ));

            System.out.println(facultyToUnsubscribeFrom.countObservers());
        }
    }
}

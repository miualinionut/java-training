package com.example.myapplication.users;

import java.util.ArrayList;

public class Repository {
    private static Repository instance = null;
    private int idOfTheClientThatIsLoggedIn;
    private ArrayList<Client> clientArrayList;
    private ArrayList<Faculty> facultyArrayList;

    private Repository() {
        idOfTheClientThatIsLoggedIn = 0;
        clientArrayList = new ArrayList<>();
        facultyArrayList = new ArrayList<>();

        clientArrayList.add(new Client("admin"));
        clientArrayList.add(new Client("Sergiu"));

        facultyArrayList.add(new Faculty("Politehnica"));
        facultyArrayList.add(new Faculty("UTCN"));
    }

    public static Repository getInstance() {
        if (instance == null) {
            instance = new Repository();
        }

        return instance;
    }

    public static void setInstance(Repository instance) {
        Repository.instance = instance;
    }

    public ArrayList<Client> getClientArrayList() {
        return clientArrayList;
    }

    public void setClientArrayList(ArrayList<Client> clientArrayList) {
        this.clientArrayList = clientArrayList;
    }

    public ArrayList<Faculty> getFacultyArrayList() {
        return facultyArrayList;
    }

    public void setFacultyArrayList(ArrayList<Faculty> facultyArrayList) {
        this.facultyArrayList = facultyArrayList;
    }

    public int getIdOfTheClientThatIsLoggedIn() {
        return idOfTheClientThatIsLoggedIn;
    }

    public void setIdOfTheClientThatIsLoggedIn(int idOfTheClientThatIsLoggedIn) {
        this.idOfTheClientThatIsLoggedIn = idOfTheClientThatIsLoggedIn;
    }
}

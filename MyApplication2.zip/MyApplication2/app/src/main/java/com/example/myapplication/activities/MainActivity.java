package com.example.myapplication.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.myapplication.R;
import com.example.myapplication.activities.ListOfFaculties;
import com.example.myapplication.users.Repository;

public class MainActivity extends AppCompatActivity {

    static boolean buttonIsPressed;
    private View prevChangedButton = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonIsPressed = false;
    }

    @SuppressLint("ResourceType")
    @Override
    protected void onStart() {
        super.onStart();
        setContentView(R.layout.activity_main);

        if (Repository.getInstance().getIdOfTheClientThatIsLoggedIn() != 0) {
            ((Button) findViewById(R.id.create_new_post_button)).setVisibility(View.INVISIBLE);
        }
    }

    public void changPageToListOfFaculties(View view) {
        Intent i = new Intent(getApplicationContext(), ListOfFaculties.class);
        startActivity(i);
    }

    public void changPageToFeed(View view) {
        Intent i = new Intent(getApplicationContext(), Feed.class);
        startActivity(i);
    }

    public void changePageToPostCreationPage(View view) {
        if (Repository.getInstance().getIdOfTheClientThatIsLoggedIn() == 0) {
            Intent i = new Intent(getApplicationContext(), PostCreationPage.class);
            startActivity(i);
        }
    }

    public void changePageToLoginPage(View view) {
        Intent i = new Intent(getApplicationContext(), LoginPage.class);
        startActivity(i);
    }

    public void toggleButton(View view) {
        if (buttonIsPressed) {
            disable(view);
        } else {
            enable(view);
        }

        buttonIsPressed = !buttonIsPressed;
    }

    public void disable(View view) {
        view.setEnabled(false);
        prevChangedButton = view;
    }

    public void enable(View view) {
        if (prevChangedButton != null) {
            prevChangedButton.setEnabled(true);
        }
    }
}
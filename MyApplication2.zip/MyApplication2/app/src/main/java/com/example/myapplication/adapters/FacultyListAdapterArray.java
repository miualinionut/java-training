package com.example.myapplication.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.myapplication.R;
import com.example.myapplication.users.Faculty;

import java.util.ArrayList;
import java.util.List;

public class FacultyListAdapterArray extends ArrayAdapter<String> {

    ArrayList<String> listItems=new ArrayList<String>();
    private int layoutResourceId;
    private Context context;

    public FacultyListAdapterArray(Context context, int layoutResourceId, ArrayList<String> listItems) {
        super(context, layoutResourceId, listItems);
        this.listItems = listItems;
        this.layoutResourceId = layoutResourceId;
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        FacultyHolder holder = null;

        LayoutInflater inflater = ((Activity) context).getLayoutInflater();
        row = inflater.inflate(layoutResourceId, parent, false);

        holder = new FacultyHolder();

        holder.facultyName = listItems.get(position);

        holder.addButton = (Button)row.findViewById(R.id.btn);
        holder.addButton.setTag(holder.facultyName);

        holder.removeButton = (Button)row.findViewById(R.id.btn2);
        holder.removeButton.setTag(holder.facultyName);

        holder.name = (TextView)row.findViewById(R.id.text1);

        row.setTag(holder);

        setupItem(holder);
        return row;
    }

    private void setupItem(FacultyHolder holder) {
        holder.name.setText(holder.facultyName);
    }

    public static class FacultyHolder {
        String facultyName;
        TextView name;
        Button addButton;
        Button removeButton;
    }
}

package com.example.myapplication.activities;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.example.myapplication.R;
import com.example.myapplication.adapters.FeedPostsAdapter;
import com.example.myapplication.posts.BasicPost;
import com.example.myapplication.users.Client;
import com.example.myapplication.users.Repository;

import java.util.ArrayList;

public class Feed extends ListActivity {

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feed);

        Repository repository = Repository.getInstance();
        ArrayList<BasicPost> currentClientsFeed = repository.getClientArrayList().
                get(repository.getIdOfTheClientThatIsLoggedIn()).getPostsInFeed();

        ArrayList<BasicPost> listItems = new ArrayList<>();

        FeedPostsAdapter adapter = new FeedPostsAdapter(this, R.layout.items_in_feed, listItems);

        setListAdapter(adapter);

        currentClientsFeed.forEach(x -> {
                    listItems.add(x);
                    adapter.notifyDataSetChanged();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        setContentView(R.layout.feed);
    }

    public void goToPreviousPage(View view) {
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(i);
    }
}

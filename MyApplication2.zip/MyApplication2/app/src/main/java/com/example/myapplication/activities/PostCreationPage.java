package com.example.myapplication.activities;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Switch;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.posts.BasicPost;
import com.example.myapplication.users.Faculty;
import com.example.myapplication.users.Repository;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;
import java.util.Optional;

public class PostCreationPage extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_post);
    }

    @Override
    protected void onStart() {
        super.onStart();
        setContentView(R.layout.create_post);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void onPost(View view) {
        System.out.println("gere");
        TextInputEditText facultyName = (TextInputEditText) findViewById(R.id.nameOfFaculty);
        TextInputEditText picture = (TextInputEditText) findViewById(R.id.picture);
        TextInputEditText text = (TextInputEditText) findViewById(R.id.text);
        @SuppressLint("UseSwitchCompatOrMaterialCode")
        Switch ratingSwitch = (Switch) findViewById(R.id.switch1);

        System.out.println(Objects.requireNonNull(facultyName.getText()).toString());

        Optional<Faculty> optionalFaculty = Repository.getInstance().getFacultyArrayList().stream().filter(
                x -> x.getName().equals(facultyName.getText().toString())
        ).findAny();

        if (optionalFaculty.isPresent()) {

            System.out.println("tries to post");
            Faculty facultyThatMakesThePost = optionalFaculty.get();

            BasicPost.PostBuilder builder = new BasicPost.PostBuilder("made by admin",
                    "faculty that posted: " + facultyName.getText().toString());

            if (picture.getText() != null) {
                if (!picture.getText().toString().isEmpty()) {
                    builder.setLinkToPicture(picture.getText().toString());
                }
            }

            if (text.getText() != null) {
                if (!text.getText().toString().isEmpty()) {
                    builder.setText(text.getText().toString());
                }
            }

            builder.setRatingBar(ratingSwitch.isChecked());

            BasicPost newPost = builder.build();

            facultyThatMakesThePost.makeAPost(newPost);
        }
    }
}

package com.example.myapplication.posts;

public class BasicPost {

    // required parameters
    private String typeOfPost;
    private String postDescription;

    // optional parameters
    private String text;
    private String linkToAPicture;
    private String linkToRegistrationForm;
    private Boolean ratingBar;

    public String getTypeOfPost() {
        return typeOfPost;
    }

    public String getPostDescription() {
        return postDescription;
    }

    public String getText() {
        return text;
    }

    public String getLinkToAPicture() {
        return linkToAPicture;
    }

    public String getLinkToRegistrationForm() {
        return linkToRegistrationForm;
    }

    public Boolean getRatingBar() {
        return ratingBar;
    }

    @Override
    public String toString() {
        String stringifiedPost = new String();

        if (typeOfPost != null) {
            stringifiedPost += "typeOfPost='" + typeOfPost + '\'';
        }

        if (postDescription != null) {
            stringifiedPost += ", postDescription='" + postDescription + '\'';
        }

        if (text != null) {
            stringifiedPost += ", text='" + text + '\'';
        }

        if (linkToAPicture != null) {
            stringifiedPost += ", linkToAPicture='" + linkToAPicture + '\'';
        }

        if (linkToRegistrationForm != null) {
            stringifiedPost += ", LinkToRegistrationForm='" + linkToRegistrationForm + '\'';
        }

        return stringifiedPost;
    }

    private BasicPost(PostBuilder builder) {
        this.typeOfPost = builder.typeOfPost;
        this.postDescription = builder.postDescription;
        this.linkToAPicture = builder.linkToAPicture;
        this.text = builder.text;
        this.linkToRegistrationForm = builder.LinkToRegistrationForm;
        this.ratingBar = builder.ratingBar;
    }

    public static class PostBuilder {
        // required parameters
        private String typeOfPost = null;
        private String postDescription = null;

        // optional parameters
        private String text = null;
        private String linkToAPicture = null;
        private String LinkToRegistrationForm = null;
        private Boolean ratingBar = false;

        public PostBuilder(String typeOfPost, String postDescription) {
            this.typeOfPost = typeOfPost;
            this.postDescription = postDescription;
        }

        public PostBuilder setText(String text) {
            this.text = text;
            return this;
        }

        public PostBuilder setLinkToPicture(String linkToAPicture) {
            this.linkToAPicture = linkToAPicture;
            return this;
        }

        public PostBuilder setLinkToRegistrationForm(String linkToRegistrationForm) {
            this.LinkToRegistrationForm = linkToRegistrationForm;
            return this;
        }

        public PostBuilder setRatingBar(Boolean ratingBar) {
            this.ratingBar = ratingBar;
            return this;
        }

        public BasicPost build() {
            return new BasicPost(this);
        }

    }
}

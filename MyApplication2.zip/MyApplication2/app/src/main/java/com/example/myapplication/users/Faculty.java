package com.example.myapplication.users;

import com.example.myapplication.posts.BasicPost;

import java.util.ArrayList;
import java.util.Observable;

public class Faculty extends Observable {
    private String name;
    private ArrayList<BasicPost> posts;

    public Faculty(String name) {
        this.name = name;
        this.posts = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<BasicPost> getPosts() {
        return posts;
    }

    public void setPosts(ArrayList<BasicPost> posts) {
        this.posts = posts;
    }

    public void makeAPost(BasicPost newPost) {
        posts.add(newPost);
        System.out.println(posts);
        this.setChanged();
        notifyObservers(newPost);
    }

    public void addToFollowers(Client client) {
        this.addObserver(client);
        client.addNewFacultyToWatchList(this);
    }

    public void removeFollowers(Client client) {
        this.deleteObserver(client);
        client.removeFacultyToWatchList(this);
    }
}
